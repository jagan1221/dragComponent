import React, { Component } from 'react'
import BasicModal from './components/Modal'
// import Home from './components/Home'
// import { Home } from '@mui/icons-material'

export default class App extends Component {
  setTodoList = (data:any) => {}
  render() {
    return (
      <BasicModal listItems={[]}/>
    )
  }
}
