import { Box, Paper, Typography } from "@mui/material";
import React, { Component } from "react";

interface ItemListProp {
  listItems: {
    id: number;
    title: string;
    description: string;
    date: string;
    status: string;
    file: any;
  }[];
}

class Itemlist extends Component<ItemListProp> {
  render() {
    const { listItems } = this.props;
    console.log(listItems,'jayakrishna');
    return (
      <Box>
        {listItems.map((item) => (
          <Paper key={item.id} style={{ padding: "10px", margin: "10px 0" }}>
            {/* <Typography variant="subtitle1">Title:{item.title}</Typography> */}
            <Typography variant="subtitle1">
              Description:{item.description}
            </Typography>
            <Typography variant="subtitle1">Date:{item.date}</Typography>
            <Typography variant="subtitle1">Status:{item.status}</Typography>
            
            <Box component='img' src = {item.file}/>

          </Paper>
        ))}
      </Box>
    );
  }
}

export default Itemlist;
