import React, { ChangeEvent, Component } from "react";
import { Container, Paper, Typography, Button, TextField } from "@mui/material";
import { Formik, Form } from "formik";
import "./index.css";
import Itemlist from "../Itemlist";
import BasicModal from "../Modal";
// import Home from "../Home";

interface FormValues {
  title: string;
  description: string;
  date: string;
  status: string;
  file: File | null;
}

interface ListItem{
    id:number;
    title:string;
    description:string;
    date:string;
    status:string
}[]

interface Props{
  values:any
}

class Details extends Component <Props,{listItems:ListItem[]}>{
  
    state = {
        listItems:[] as ListItem[]
    }

  handleFileChange = (event: ChangeEvent<HTMLInputElement>, form: any) => {
    if (event.target.files && event.target.files.length > 0) {
      form("file", event.target.files[0]);
    }
  };
  handleSubmit=(values: FormValues, { resetForm }: any) => {
    const newItem:ListItem = {
        id:Date.now(),
        ...values,

    }

    this.setState((prev) =>({
        listItems:[...prev.listItems,newItem]
    }))
    this.modalData()
    console.log("Form submitted with data:", this.state.listItems);
    resetForm();
  }

  modalData = () =>{
    console.log("modal data")
    this.props.values(this.state.listItems)
  }

  render() {
    const {listItems} = this.state
    return (
      <Container maxWidth="xs">
        <Paper elevation={3} style={{ padding: "20px" }}>
          <Formik<FormValues>
            initialValues={{
              title: "",
              description: "",
              date: "",
              status: "",
              file: null,
            }}
            validate={(values) => {
              const errors: Partial<FormValues> = {};

              if (!values.title) {
                errors.title = "title is required";
              }
              if (!values.description) {
                errors.description = "description is description";
              }
              if (!values.date) {
                errors.date = "select the date";
              }
              if (!values.status) {
                errors.status = "write the status";
              }

              return errors;
            }}
            onSubmit={this.handleSubmit}
          >
            {({
              values,
              errors,
              handleChange,
              handleSubmit,
              setFieldValue,
            }) => (
              <Form onSubmit={handleSubmit}>
                <TextField
                  fullWidth
                  label="title"
                  name="title"
                  value={values.title}
                  onChange={handleChange}
                  margin="normal"
                  variant="outlined"
                  error={!!errors.title}
                  helperText={errors.title}
                />

                <TextField
                  fullWidth
                  label="description"
                  name="description"
                  value={values.description}
                  onChange={handleChange}
                  margin="normal"
                  variant="outlined"
                  error={!!errors.description}
                  helperText={errors.description}
                />

                <TextField
                  fullWidth
                  //   label="date"
                  type="date"
                  name="date"
                  value={values.date}
                  onChange={handleChange}
                  margin="normal"
                  variant="outlined"
                  error={!!errors.date}
                  helperText={errors.date}
                />

                <TextField
                  fullWidth
                  label="status"
                  type="tex"
                  name="status"
                  value={values.status}
                  onChange={handleChange}
                  margin="normal"
                  variant="outlined"
                  error={!!errors.status}
                  helperText={errors.status}
                />
                <input
                  type="file"
                  accept=".jpg, .jpeg, .png"
                  onChange={(event) =>
                    this.handleFileChange(event, setFieldValue)
                  }
                  className="file-input"
                  style={{ marginTop: "10px" }}
                />

                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  fullWidth
                  style={{ marginTop: "10px" }}
                >
                  Add
                </Button>
              </Form>
            )}
          </Formik>
        </Paper>
        {/* <Itemlist listItems = {listItems}/> */}
      </Container>
    );
  }
}

export default Details;
