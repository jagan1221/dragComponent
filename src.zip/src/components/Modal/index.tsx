import * as React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import Details from "../Details";
import Itemlist from "../Itemlist";

// Define the interface for the list items
interface ItemListProp {
  listItems: {
    id: number;
    title: string;
    description: string;
    date: string;
    status: string;
  }[];
}

const style = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

const BasicModal: React.FC<ItemListProp> = ({ listItems }) => {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [listdata, SetlisData] = React.useState([]);

  const propsdrill = (data: any) => {
    console.log("jdshfkjdj", data);
    SetlisData(data);
  };

  return (
    <div>
      <Itemlist listItems={listdata} />
      <Button onClick={handleOpen}>Open modal</Button>

      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Details values={propsdrill} />
        </Box>
      </Modal>
    </div>
  );
};

export default BasicModal;
